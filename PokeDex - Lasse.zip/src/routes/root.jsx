import { useParams, Outlet } from "react-router-dom";

import Navbar from "../components/Navbar";

export default function Root() {
    return (
      <>
        <Navbar />
        <Outlet />
      </>
    );
  }